<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AgentsController extends Controller
{
    public function index()
    {
        $logFile = base_path('../ai-agent-roadmap/logs/agent-log.jsonl');

        // Define known agents (fallback will show them even if no activity yet)
        $knownAgents = ['DevAgent', 'ContentAgent'];

        $agents = [];

        // Seed known agents with fallback defaults
        foreach ($knownAgents as $agentName) {
            $agents[$agentName] = [
                'name'       => $agentName,
                'status'     => 'offline',
                'last_task'  => 'No activity yet',
                'last_seen'  => '-',
                'badgeClass' => 'badge-dark',
                'rowClass'   => 'table-dark',
                'icon'       => '⚫',
                'label'      => 'Offline',
            ];
        }

        // If log file exists, override with actual logs
        if (file_exists($logFile)) {
            $lines = file($logFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

            foreach ($lines as $line) {
                $entry = json_decode($line, true);
                if (!$entry || !isset($entry['agent'])) continue;

                $agentName = $entry['agent'];

                // Map status → styles
                $status = $entry['status'] ?? 'log';
                $styleMap = [
                    'completed'    => ['badge-success', 'table-success', '✅', 'Completed'],
                    'failed'       => ['badge-danger', 'table-danger', '❌', 'Failed'],
                    'pending'      => ['badge-warning', 'table-warning', '⏳', 'Pending'],
                    'in-progress'  => ['badge-info', 'table-info', '📤', 'In Progress'],
                    'log'          => ['badge-secondary', 'table-light', '📝', 'Log'],
                    'offline'      => ['badge-dark', 'table-dark', '⚫', 'Offline'],
                ];

                [$badgeClass, $rowClass, $icon, $label] =
                    $styleMap[$status] ?? $styleMap['log'];

                // Update with the latest activity
                $agents[$agentName] = [
                    'name'       => $agentName,
                    'status'     => $status,
                    'last_task'  => $entry['task'] ?? 'No activity yet',
                    'last_seen'  => $entry['time'] ?? '-',
                    'badgeClass' => $badgeClass,
                    'rowClass'   => $rowClass,
                    'icon'       => $icon,
                    'label'      => $label,
                ];
            }
        }

        return view('agents.index', ['agents' => $agents]);
    }
	
	public function history($agentName)
	{
		$logFile = base_path('../ai-agent-roadmap/logs/agent-log.jsonl');
		$entries = [];

		if (file_exists($logFile)) {
			$lines = file($logFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

			foreach ($lines as $line) {
				$entry = json_decode($line, true);
				if (!$entry || ($entry['agent'] ?? '') !== $agentName) continue;

				$entries[] = $entry;
			}
		}

		return view('agents.history', [
			'agent'   => $agentName,
			'entries' => array_reverse($entries), // latest first
		]);
	}
	
	public function addTask(Request $request, $agentName)
	{
		$task = $request->input('task');

		// Log dispatch via BrainBox (reuse the logging pipeline)
		$logFile = base_path('../ai-agent-roadmap/logs/agent-log.jsonl');
		$entry = [
			'time'   => date('Y-m-d H:i:s'),
			'agent'  => $agentName,
			'status' => 'dispatched',
			'task'   => $task,
			'source' => 'Dashboard',
		];

		file_put_contents($logFile, json_encode($entry) . PHP_EOL, FILE_APPEND);

		return redirect()->route('agents.index')
			->with('success', "Task dispatched to {$agentName}: {$task}");
	}


}
