@extends('layouts.app')

@section('content')
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">{{ $agent }} – History</h1>
    <a href="{{ route('agents.index') }}" class="btn btn-sm btn-secondary">
        ← Back to Agents
    </a>
</div>

<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Activity Log</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-sm table-bordered mb-0">
                <thead>
                    <tr>
                        <th>Time</th>
                        <th>Status</th>
                        <th>Task</th>
                    </tr>
                </thead>
							<tbody>
				@forelse($entries as $entry)
					@php
						$rowClass = '';
						$badgeClass = 'badge-secondary';
						$icon = '📝'; $label = ucfirst($entry['status']);

						switch ($entry['status']) {
							case 'completed': $rowClass='table-success'; $badgeClass='badge-success'; $icon='✅'; $label='Completed'; break;
							case 'failed': $rowClass='table-danger'; $badgeClass='badge-danger'; $icon='❌'; $label='Failed'; break;
							case 'pending': $rowClass='table-warning'; $badgeClass='badge-warning'; $icon='⏳'; $label='Pending'; break;
							case 'in-progress': $rowClass='table-info'; $badgeClass='badge-info'; $icon='📤'; $label='In Progress'; break;
						}
					@endphp

					<tr class="{{ $rowClass }}">
						<td>{{ $entry['time'] ?? '-' }}</td>
						<td><span class="badge {{ $badgeClass }}">{{ $icon }} {{ $label }}</span></td>
						<td>{{ $entry['task'] ?? '-' }}</td>
					</tr>
				@empty
					<tr>
						<td colspan="3" class="text-center text-muted">No activity yet for this agent.</td>
					</tr>
				@endforelse
			</tbody>

            </table>
        </div>
    </div>
</div>
@endsection
