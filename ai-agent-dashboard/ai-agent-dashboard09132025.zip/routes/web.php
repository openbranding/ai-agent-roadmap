<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\AgentsController;


Route::get('/', [ReportController::class, 'dashboard'])->name('dashboard');
Route::get('/dashboard', [ReportController::class, 'dashboard']);

// Reports Page (table of logs)
Route::get('/reports', [ReportController::class, 'index'])->name('reports.index');

Route::get('/reports/export/{format}', [ReportController::class, 'export'])->name('reports.export');

Route::get('/agents', [AgentsController::class, 'index'])->name('agents.index');

Route::get('/agents/{agent}/history', [AgentsController::class, 'history'])->name('agents.history');

Route::post('/agents/{agent}/tasks', [AgentsController::class, 'addTask'])->name('agents.addTask');





