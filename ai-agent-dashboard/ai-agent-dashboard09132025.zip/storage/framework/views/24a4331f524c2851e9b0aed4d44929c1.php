

<?php $__env->startSection('content'); ?>
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Agents</h1>
</div>

<div class="row">
    <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card <?php echo e($agent['rowClass']); ?> shadow h-100 py-2">
                <div class="card-body">
                    <div class="text-xs font-weight-bold text-uppercase mb-1">
                        <?php echo e($agent['name']); ?>

                    </div>
                    <div class="h5 mb-0 font-weight-bold">
                        <span class="badge <?php echo e($agent['badgeClass']); ?>">
                            <?php echo e($agent['icon']); ?> <?php echo e($agent['label']); ?>

                        </span>
                    </div>
                    <div class="mt-2 small text-muted">
                        Last task: <?php echo e($agent['last_task']); ?> <br>
                        Seen: <?php echo e($agent['last_seen']); ?>

                    </div>

                    <!-- Actions -->
					<div class="mt-3">
						<a href="<?php echo e(route('agents.history', $agent['name'])); ?>" class="btn btn-sm btn-outline-primary">
							<i class="fas fa-history"></i> View History
						</a>
						<!-- Trigger modal -->
						<button class="btn btn-sm btn-outline-success" data-toggle="modal" data-target="#taskModal-<?php echo e($agent['name']); ?>">
							<i class="fas fa-plus"></i> Add Task
						</button>
					</div>

                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<!-- Quick table below -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Agent Summary</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-sm table-bordered">
                <thead>
                    <tr>
                        <th>Agent</th>
                        <th>Status</th>
                        <th>Last Task</th>
                        <th>Last Seen</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="<?php echo e($agent['rowClass']); ?>">
                            <td><?php echo e($agent['name']); ?></td>
                            <td>
                                <span class="badge <?php echo e($agent['badgeClass']); ?>">
                                    <?php echo e($agent['icon']); ?> <?php echo e($agent['label']); ?>

                                </span>
                            </td>
                            <td><?php echo e($agent['last_task']); ?></td>
                            <td><?php echo e($agent['last_seen']); ?></td>
                            <td>
                                <a href="#" class="btn btn-sm btn-outline-primary">
                                    <i class="fas fa-history"></i>
                                </a>
                                <a href="#" class="btn btn-sm btn-outline-success">
                                    <i class="fas fa-plus"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="5" class="text-center text-muted">No agents found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="taskModal-<?php echo e($agent['name']); ?>" tabindex="-1">
  <div class="modal-dialog">
    <form method="POST" action="<?php echo e(route('agents.addTask', $agent['name'])); ?>">
        <?php echo csrf_field(); ?>
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add Task for <?php echo e($agent['name']); ?></h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <textarea name="task" class="form-control" placeholder="Enter task..." required></textarea>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-success">Dispatch</button>
            </div>
        </div>
    </form>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\ai-agent-dashboard\resources\views/agents/index.blade.php ENDPATH**/ ?>