

<?php $__env->startSection('content'); ?>
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><?php echo e($agent); ?> – History</h1>
    <a href="<?php echo e(route('agents.index')); ?>" class="btn btn-sm btn-secondary">
        ← Back to Agents
    </a>
</div>

<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Activity Log</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-sm table-bordered mb-0">
                <thead>
                    <tr>
                        <th>Time</th>
                        <th>Status</th>
                        <th>Task</th>
                    </tr>
                </thead>
							<tbody>
				<?php $__empty_1 = true; $__currentLoopData = $entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
					<?php
						$rowClass = '';
						$badgeClass = 'badge-secondary';
						$icon = '📝'; $label = ucfirst($entry['status']);

						switch ($entry['status']) {
							case 'completed': $rowClass='table-success'; $badgeClass='badge-success'; $icon='✅'; $label='Completed'; break;
							case 'failed': $rowClass='table-danger'; $badgeClass='badge-danger'; $icon='❌'; $label='Failed'; break;
							case 'pending': $rowClass='table-warning'; $badgeClass='badge-warning'; $icon='⏳'; $label='Pending'; break;
							case 'in-progress': $rowClass='table-info'; $badgeClass='badge-info'; $icon='📤'; $label='In Progress'; break;
						}
					?>

					<tr class="<?php echo e($rowClass); ?>">
						<td><?php echo e($entry['time'] ?? '-'); ?></td>
						<td><span class="badge <?php echo e($badgeClass); ?>"><?php echo e($icon); ?> <?php echo e($label); ?></span></td>
						<td><?php echo e($entry['task'] ?? '-'); ?></td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
					<tr>
						<td colspan="3" class="text-center text-muted">No activity yet for this agent.</td>
					</tr>
				<?php endif; ?>
			</tbody>

            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\ai-agent-dashboard\resources\views/agents/history.blade.php ENDPATH**/ ?>