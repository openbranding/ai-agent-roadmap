<?php
/**
 * DevAgent.php — Developer Agent stub with step logging
 */

date_default_timezone_set('UTC');

$task = $argv[1] ?? "No task provided";

echo "👨‍💻 DevAgent starting task: {$task}\n";

// Logging helper
function logStep($agent, $task, $status) {
    $logFile = __DIR__ . "/../logs/agent-log.jsonl";
    if (!file_exists(dirname($logFile))) {
        mkdir(dirname($logFile), 0777, true);
    }
    $logEntry = [
        "timestamp" => date('Y-m-d H:i:s'),
        "agent"     => $agent,
        "task"      => $task,
        "status"    => $status,
        "source"    => "DevAgent"
    ];
    file_put_contents($logFile, json_encode($logEntry) . PHP_EOL, FILE_APPEND);
}

// Fake Laravel setup steps
if (stripos($task, 'laravel') !== false) {
    $steps = [
        "Checking PHP and Composer environment",
        "Running composer create-project laravel/laravel example-app",
        "Installing Laravel Breeze for auth scaffolding",
        "Seeding .env.example with database credentials"
    ];
    foreach ($steps as $s) {
        echo "   ➤ {$s}...\n";
        logStep("DevAgent", $s, "in-progress");
        sleep(1);
    }
    echo "   ✅ Laravel project initialized successfully.\n";
    logStep("DevAgent", "Laravel project initialization", "completed");
} else {
    echo "   ⚠️ Task not recognized as Laravel setup.\n";
    logStep("DevAgent", "Unrecognized task: {$task}", "failed");
}

echo "👨‍💻 DevAgent finished task: {$task}\n";
