<!-- Footer -->
<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>© AI Agent Team Dashboard 2025</span>
        </div>
    </div>
</footer>
<!-- End Footer -->
