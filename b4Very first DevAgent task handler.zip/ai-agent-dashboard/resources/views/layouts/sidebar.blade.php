<!-- Sidebar -->
<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

    <!-- Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="{{ url('/') }}">
        <div class="sidebar-brand-icon rotate-n-15">
            <i class="fas fa-robot"></i>
        </div>
        <div class="sidebar-brand-text mx-3">AI Agent</div>
    </a>

    <hr class="sidebar-divider my-0">

    <!-- Nav Items -->
    <li class="nav-item active">
        <a class="nav-link" href="{{ url('/') }}">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span>
        </a>
    </li>

    <li class="nav-item">
        <a class="nav-link" href="{{ url('/reports') }}">
            <i class="fas fa-fw fa-chart-line"></i>
            <span>Reports</span>
        </a>
    </li>

    <li class="nav-item">
        <a class="nav-link" href="{{ url('/agents') }}">
            <i class="fas fa-fw fa-users"></i>
            <span>Agents</span>
        </a>
    </li>

    <hr class="sidebar-divider">

    <li class="nav-item">
        <a class="nav-link" href="{{ url('/settings') }}">
            <i class="fas fa-fw fa-cogs"></i>
            <span>Settings</span>
        </a>
    </li>
	
	<li class="nav-item">
    <a class="nav-link" href="{{ route('reports.index') }}">
        <i class="fas fa-clipboard-list"></i>
        <span>Reports</span>
    </a>
</li>


    <hr class="sidebar-divider d-none d-md-block">

</ul>
<!-- End Sidebar -->
